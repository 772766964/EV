package com.ev.service;

import com.ev.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author orlando
 * @since 2023-03-24
 */
public interface UserService extends IService<User> {

}
