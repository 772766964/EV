package com.ev.service;

import com.ev.entity.Role;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author orlando
 * @since 2023-03-24
 */
public interface RoleService extends IService<Role> {

}
