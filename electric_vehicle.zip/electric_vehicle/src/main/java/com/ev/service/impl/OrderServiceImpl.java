package com.ev.service.impl;

import com.ev.entity.Order;
import com.ev.dao.OrderMapper;
import com.ev.service.OrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author orlando
 * @since 2023-03-24
 */
@Service
public class OrderServiceImpl extends ServiceImpl<OrderMapper, Order> implements OrderService {

}
