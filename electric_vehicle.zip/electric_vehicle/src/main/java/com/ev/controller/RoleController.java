package com.ev.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author orlando
 * @since 2023-03-24
 */
@RestController
@RequestMapping("/role")
public class RoleController {

}

