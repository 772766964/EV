package com.ev.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author orlando
 * @since 2023-03-24
 */
@Getter
@Setter
@Accessors(chain = true)
public class Car implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "cid", type = IdType.AUTO)
    private Integer cid;

    private String name;

    private String developers;

    private String price;

    private String type;

    private String createTime;

    private String updateTime;

    private Integer deleted;


}
