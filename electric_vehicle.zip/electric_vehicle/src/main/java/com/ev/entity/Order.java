package com.ev.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author orlando
 * @since 2023-03-24
 */
@Getter
@Setter
@Accessors(chain = true)
public class Order implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "oid", type = IdType.AUTO)
    private Integer oid;

    private Integer rid;

    private Integer ridBuyer;

    private Integer cid;

    private String createTime;

    private String updateTime;

    private String orderedTime;

    private Integer deleted;


}
