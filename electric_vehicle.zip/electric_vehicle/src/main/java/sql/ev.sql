
CREATE DATABASE `ev` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;


use `ev`;


drop table user;


CREATE TABLE `user` (
`uid` int(10) unsigned NOT NULL auto_increment primary key,
`name` char(12) default '用户',
`true_name` int(18)default '0',
`sex` enum('保密','男','女') character set utf8 NOT NULL default '保密',
`phone` int(11),
`password` int(12),
`id` varchar(50) character set utf8 NULL default '',
`create_time` varchar(50) character set utf8 NOT NULL default '',
`update_time` varchar(50) character set utf8 NOT NULL default '',
`deleted` TINYINT default 0
) DEFAULT CHARSET=utf8;



-- 用户0 销售1 管理2
CREATE TABLE `role` (
`rid` int(10) unsigned NOT NULL auto_increment primary key,
`rname` varchar(50) character set utf8 NOT NULL default '',
`create_time` varchar(50) character set utf8 NOT NULL default '',
`update_time` varchar(50) character set utf8 NOT NULL default '',
`deleted` TINYINT default 0
) DEFAULT CHARSET=utf8;



CREATE TABLE `user_role` (
`uid` int(10),
`rid` int(10),
`create_time` varchar(50) character set utf8 NOT NULL default '',
`update_time` varchar(50) character set utf8 NOT NULL default '',
`deleted` TINYINT default 0,
 Primary Key(uid,rid)
) DEFAULT CHARSET=utf8;




CREATE TABLE `car` (
`cid` int(10) unsigned NOT NULL auto_increment primary key,
`name` char(10),
`developers` char(10),
`price` char(10),
`type` char(10),
`create_time` varchar(50) character set utf8 NOT NULL default '',
`update_time` varchar(50) character set utf8 NOT NULL default '',
`deleted` TINYINT default 0
) DEFAULT CHARSET=utf8;






CREATE TABLE `order` (
`oid` int(10)primary key,
`rid` int(10),
`rid_buyer` int(10),
`cid` int(10),
`create_time` varchar(50) character set utf8 NOT NULL default '',
`update_time` varchar(50) character set utf8 NOT NULL default '',
`ordered_time` varchar(50) character set utf8 NOT NULL default '',
`deleted` TINYINT default 0
) DEFAULT CHARSET=utf8;





-- --------------------------------------------------------------

CREATE TABLE `type` (
`id` int(10) unsigned NOT NULL auto_increment primary key,
`flag_deleted` enum('Y','N') character set utf8 NOT NULL default 'N',
`flag_type` int(5) NOT NULL default '0',
`type_name` varchar(50) character set utf8 NOT NULL default '',
`create_time` varchar(50) character set utf8 NOT NULL default '',
`update_time` varchar(50) character set utf8 NOT NULL default '',
`deleted` TINYINT default 0
) DEFAULT CHARSET=utf8;